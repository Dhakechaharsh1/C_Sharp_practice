﻿using System;

public class Patient
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public double Weight { get; set; } // in KG
    public double Height { get; set; } // in Centimeters

    // Constructor
    public Patient(string firstName, string lastName, double weight, double height)
    {
        FirstName = firstName;
        LastName = lastName;
        Weight = weight;
        Height = height;
    }

    // Method to calculate blood pressure based on systolic and diastolic values
    public string CalculateBloodPressure(int systolic, int diastolic)
    {
        if (systolic < 0 || diastolic < 0)
        {
            return "Invalid blood pressure values";
        }
        else if (systolic < 120 && diastolic < 80)
        {
            return "NORMAL";
        }
        else if (systolic < 130 && diastolic < 80)
        {
            return "ELEVATED";
        }
        else if (systolic < 140 || diastolic < 90)
        {
            return "HIGH BLOOD PRESSURE (HYPERTENSION) STAGE 1";
        }
        else if (systolic >= 140 || diastolic >= 90)
        {
            return "HIGH BLOOD PRESSURE (HYPERTENSION) STAGE 2";
        }
        else if (systolic >= 180 && diastolic >= 120)
        {
            return "HYPERTENSIVE CRISIS (consult your doctor immediately)";
        }
        else
        {
            return "Blood pressure values are not within the defined ranges";
        }
    }

    // Method to calculate BMI (Body Mass Index)
    public double CalculateBMI()
    {
        double heightInMeters = Height / 100.0; // Convert height from centimeters to meters
        return Weight / (heightInMeters * heightInMeters);
    }

    // Method to print patient information
    public void PrintPatientInformation()
    {
        Console.WriteLine("\n\nFull Name: " + FirstName + " " + LastName);
        Console.WriteLine("Weight: " + Weight + " KG");
        Console.WriteLine("Height: " + Height + " CM");
        Console.WriteLine("Blood Pressure: " + CalculateBloodPressure(120, 80));
        Console.WriteLine("BMI: " + CalculateBMI());

        double bmi = CalculateBMI();
        if (bmi >= 25.0)
        {
            Console.WriteLine("BMI Status: Overweight");
        }
        else if (bmi >= 18.5 && bmi <= 24.9)
        {
            Console.WriteLine("BMI Status: Normal (In the healthy range)");
        }
        else
        {
            Console.WriteLine("BMI Status: Underweight");
        }
    }
}
