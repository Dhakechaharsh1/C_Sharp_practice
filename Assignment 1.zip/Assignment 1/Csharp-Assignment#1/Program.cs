﻿class Program
{
    static void Main(string[] args)
    {
        //Ask the user to enter their age
        Console.Write("Enter your age: ");
        int age = int.Parse(Console.ReadLine());

        Console.WriteLine("\n----------------------------------------------------------------------");
        //Ask the user to insert the patient information
        Console.WriteLine("Enter the patient information below");
        Console.WriteLine("----------------------------------------------------------------------");

        Console.Write("\nFirst Name: ");
        string firstName = Console.ReadLine();
       
        Console.Write("Last Name: ");
        string lastName = Console.ReadLine();
       
        Console.Write("Weight (in KG): ");
        double weight = double.Parse(Console.ReadLine());
        
        Console.Write("Height (in Centimeters): ");
        double height = double.Parse(Console.ReadLine());

        Console.WriteLine("\n\n----------------------------------------------------------------------");

        //Create an instance of the Patient class and print the patient information
        Patient patient = new Patient(firstName, lastName, weight, height);
        patient.PrintPatientInformation();

        
        Console.ReadKey();
    }
}
